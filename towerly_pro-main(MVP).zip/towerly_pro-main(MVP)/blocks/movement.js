
Blockly.defineBlocksWithJsonArray([{
  "type": "movement",
  "message0": "Movement %1",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "NAME",
      "options": [
        [
          "Up",
          "U"
        ],
        [
          "Down",
          "D"
        ],
        [
          "Right",
          "R"
        ],
        [
          "Left",
          "L"
        ]
      ]
    }
  ],
  "previousStatement": null,
  "nextStatement": null,
  "colour": 230,
  "tooltip": "",
  "helpUrl": ""
}])